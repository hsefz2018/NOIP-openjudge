a=raw_input()
b=raw_input()
print int(a)+int(b)
