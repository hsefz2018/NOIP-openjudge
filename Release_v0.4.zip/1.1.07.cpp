#include<cstdio>

int main(){
    double a;
    scanf("%lf",&a);
    printf("%f\n",a);
    printf("%.5f\n",a);
    printf("%e\n",a);
    printf("%g\n",a);
    return 0;
}
