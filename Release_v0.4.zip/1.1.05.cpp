#include<cstdio>

int main(){
    double a;
    scanf("%lf",&a);
    printf("%.12f",a);
    return 0;
}
