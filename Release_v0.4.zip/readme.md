# NOIP-OpenJudge

Repo for [noi.openjudge.cn](http://noi.openjudge.cn/)

For more details, see [Intro Page](http://magetron.github.io/NOIP-openjudge/)

## License

This repo is under MIT License.

## Wonna Contribute?

Contact [magetron](http://scr.im/patrickw)

## Current Progress

#### Total Progress: 100/313 

#### Issues
WA Bug Fix needed for 1.4.13.pas

