#include<iostream>

using namespace std;

int main(){
    int a;
    bool f;
    cin >> a;
    f = a;
    a = f;
    cout << a;
    return 0;
}

