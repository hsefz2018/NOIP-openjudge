#include<iostream>

using namespace std;

int main(){
    cout << sizeof("Hello, World!");
    return 0;
}

